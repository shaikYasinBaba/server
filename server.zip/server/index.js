// create_tables.js
const sqlite3 = require('sqlite3').verbose();

// Connect to SQLite database
let db = new sqlite3.Database('auth.db');

db.serialize(() => {
    // Create studentdata table
    db.run(`
        CREATE TABLE IF NOT EXISTS studentdata (
            hallticketnumber TEXT PRIMARY KEY,
            fullname TEXT NOT NULL,
            gender TEXT NOT NULL,
            dateofbirth TEXT NOT NULL,
            school TEXT NOT NULL
        )
    `);

    // Create results table
    db.run(`
        CREATE TABLE IF NOT EXISTS results (
            hallticketnumber TEXT PRIMARY KEY,
            telugu INTEGER,
            hindhi INTEGER,
            english INTEGER,
            mathematics INTEGER,
            science INTEGER,
            social INTEGER,
            result TEXT,
            FOREIGN KEY (hallticketnumber) REFERENCES studentdata(hallticketnumber)
        )
    `, (err) => {
        if (err) {
            console.error("Error creating results table:", err.message);
        } else {
            console.log("Tables created successfully");
        }
    });
});

db.close();
