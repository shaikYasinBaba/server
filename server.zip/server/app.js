// app.js
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const SECRET_KEY = 'your_secret_key';

app.use(bodyParser.json());
app.use(cors());

// Check user credentials
const checkUser = (username, password, callback) => {
    let db = new sqlite3.Database('auth.db');
    db.get('SELECT password FROM authentication WHERE username = ?', [username], (err, row) => {
        if (err) {
            callback(err);
        } else if (row) {
            bcrypt.compare(password, row.password, (err, res) => {
                callback(err, res);
            });
        } else {
            callback(null, false);
        }
    });
    db.close();
};

//authenticationfunction 
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) return res.sendStatus(403);

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Login route
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    checkUser(username, password, (err, isValid) => {
        if (err) {
            res.status(500).json({ message: 'Internal server error' });
        } else if (isValid) {
            const token = jwt.sign({ username }, SECRET_KEY, { expiresIn: '1h' });
            res.json({ token });
        } else {
            res.status(401).json({ message: 'Invalid credentials' });
        }
    });
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

// app.js

// API to add student data
app.post('/studentdata', authenticateToken, (req, res) => {
    const { hallticketnumber, fullname, gender, dateofbirth, school } = req.body;

    if (!hallticketnumber || !fullname || !gender || !dateofbirth || !school) {
        return res.status(400).json({ message: 'All fields are required' });
    }
    let db = new sqlite3.Database('auth.db');
    db.run(`
        INSERT INTO studentdata (hallticketnumber, fullname, gender, dateofbirth, school)
        VALUES (?, ?, ?, ?, ?)
    `, [hallticketnumber, fullname, gender, dateofbirth, school], (err) => {
        if (err) {
            return res.status(500).json({ message: 'Error inserting student data' });
        }
        res.status(201).json({ message: 'Student data added successfully' });
    });
    db.close();
});
// app.js

// API to add result data
app.post('/results', authenticateToken, (req, res) => {
    const { hallticketnumber, telugu, hindhi, english, mathematics, science, social, result } = req.body;

    if (!hallticketnumber || telugu === undefined || hindhi === undefined || english === undefined || mathematics === undefined || science === undefined || social === undefined || !result) {
        return res.status(400).json({ message: 'All fields are required' });
    }
    let db = new sqlite3.Database('auth.db');
    // Check if hallticketnumber exists in studentdata table
    db.get('SELECT hallticketnumber FROM studentdata WHERE hallticketnumber = ?', [hallticketnumber], (err, row) => {
        if (err) {
            return res.status(500).json({ message: 'Error querying student data' });
        }
        if (!row) {
            return res.status(404).json({ message: 'Hallticket number not found in student data' });
        }

        // Insert result data
        db.run(`
            INSERT INTO results (hallticketnumber, telugu, hindhi, english, mathematics, science, social, result)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [hallticketnumber, telugu, hindhi, english, mathematics, science, social, result], (err) => {
            if (err) {
                return res.status(500).json({ message: 'Error inserting result data' });
            }
            res.status(201).json({ message: 'Result data added successfully' });
        });
    });
    db.close();
});
//halltiket number

app.get('/student/:hallticketnumber', (req, res) => {
    const { hallticketnumber } = req.params;

    let db = new sqlite3.Database('auth.db');

    let studentQuery = `SELECT * FROM studentdata WHERE hallticketnumber = ?`;
    let resultsQuery = `SELECT * FROM results WHERE hallticketnumber = ?`;

    let studentData = {};
    let resultsData = [];

    db.get(studentQuery, [hallticketnumber], (err, row) => {
        if (err) {
            db.close();
            return res.status(500).json({ message: 'Error retrieving student data' });
        }
        if (!row) {
            db.close();
            return res.status(404).json({ message: 'Student not found' });
        }
        studentData = row;
        // Once student data is fetched, execute the query to fetch results
        db.all(resultsQuery, [hallticketnumber], (err, rows) => {
            if (err) {
                db.close();
                return res.status(500).json({ message: 'Error retrieving results data' });
            }
            resultsData = rows;
            // Combine student data and results and send as response
            let combinedData = { ...studentData, results: resultsData };
            res.json(combinedData);
            db.close();
        });
    });
});

app.get('/students/no-results', authenticateToken, (req, res) => {
    let db = new sqlite3.Database('auth.db');
    db.all(`
        SELECT studentdata.hallticketnumber, studentdata.fullname
        FROM studentdata
        LEFT JOIN results ON studentdata.hallticketnumber = results.hallticketnumber
        WHERE results.hallticketnumber IS NULL
    `, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Error retrieving student data' });
        }
        res.json(rows);
    });
    db.close();
});

// app.js
app.get('/students/results', authenticateToken, (req, res) => {
    let db = new sqlite3.Database('auth.db');

    db.all(`
        SELECT 
            studentdata.hallticketnumber, 
            studentdata.fullname, 
            results.result
        FROM studentdata
        INNER JOIN results ON studentdata.hallticketnumber = results.hallticketnumber
        WHERE results.result IS NOT NULL
    `, [], (err, rows) => {
        if (err) {
            return res.status(500).json({ message: 'Error retrieving students results' });
        }
        res.json(rows);
    });

    db.close();
});

// Endpoint to delete student data
app.delete('/delete-student/:hallticketnumber', authenticateToken, (req, res) => {
    const { hallticketnumber } = req.params;
    let db = new sqlite3.Database('auth.db');

    db.serialize(() => {
        db.run('DELETE FROM studentdata WHERE hallticketnumber = ?', [hallticketnumber], (err) => {
            if (err) {
                return res.status(500).json({ message: 'Error deleting student data' });
            }
        });

        db.run('DELETE FROM results WHERE hallticketnumber = ?', [hallticketnumber], (err) => {
            if (err) {
                return res.status(500).json({ message: 'Error deleting student results' });
            }
        });

        res.json({ message: 'Student data deleted successfully' });
    });

    db.close();
});
